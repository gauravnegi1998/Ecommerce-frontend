import { Component, OnInit } from '@angular/core';
import { InputModules } from '../../inputs/inputs.module';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [InputModules],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent implements OnInit {

  emailValue: string = "";
  passwordValue: string = "";

  ngOnInit(): void {
    console.log(this.emailValue, ">>>>>>>>>", this.passwordValue)
  }

  _handleOnChange(event: any) {
    console.log(event, " > > > > > > > >  > > > > > > ", this.emailValue)
  }
}
